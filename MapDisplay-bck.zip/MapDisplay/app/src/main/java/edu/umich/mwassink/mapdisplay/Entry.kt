package edu.umich.mwassink.mapdisplay

object Entry {
    var id: String = "1"
    var x: Double = 365.0
    var y: Double = 22.0
    var floorNumber: Int = 1
}