package edu.umich.wwf

//class EntranceNode(latitude: Double, longitude: Double, neighbors: ArrayList<Node>)
//    : Node(latitude, longitude, neighbors)