package edu.umich.mwassink.mapdisplay

class User(var lat: Double = 0.0, var lon: Double = 0.0, var loc: String = "",
              var facing: String = "unknown", var speed: Float = 0.0f)

//    fun getUserLocation() {
//        var (longitude, latitude) = UpdateUserLocation.getLocationFromGPS()
//    }
//
//    fun getNearestNode() {
//
//    }

