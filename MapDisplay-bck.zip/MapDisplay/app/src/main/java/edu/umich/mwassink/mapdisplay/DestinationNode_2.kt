package edu.umich.wwf

//class DestinationNode(latitude: Double, longitude: Double, neighbors: ArrayList<Node>) : Node(latitude, longitude, neighbors)