package edu.umich.mwassink.mapdisplay

object Room {
    var number: String = "1670"
    var x: Double = 329.0
    var y: Double = 357.0
}